public class AirlineReservation{

public static void main(String[] args) {
    
}
}